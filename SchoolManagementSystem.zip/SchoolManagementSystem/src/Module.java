import java.lang.reflect.Array;
import java.util.*;

public class Module {
    private int moduleID;
    private String moduleName;
    private int maxCapacity;
    private ArrayList<Assessment> assessments;

    
    public Module(int moduleID) {
        this.moduleID = moduleID;
    }

    
    public Module(String moduleName) {
        this.moduleName = moduleName;
    }

    
    public void setModuleID(int moduleID) {
        this.moduleID = moduleID;
    }

    public int getModuleID() {
        return moduleID;
    }

    
    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getModuleName() {
        return moduleName;
    }

    
    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    
    public void addModule(ArrayList<Module> modules, Module newModule) {
        modules.add(newModule);
    }
    public void setAssessments(ArrayList<Assessment> assessments) {
        this.assessments = assessments;
    }
    public ArrayList<Assessment> getAssessments() {
        return assessments;
    }
    
    public void removeModule(ArrayList<Module> modules, Module removedModule) {
        modules.remove(removedModule);
    }

    
    public void updateModule(ArrayList<Module> modules, Module editedModule) {
        for (Module m : modules) {
            if (m.getModuleID() == editedModule.getModuleID()) {
                m.setModuleName(editedModule.getModuleName());
                m.setMaxCapacity(editedModule.getMaxCapacity());
            }
        }
    }
}
