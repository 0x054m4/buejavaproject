
    public class Admin extends Staff {

    public Admin(int staffId) {
        super(staffId);  
    }


}
